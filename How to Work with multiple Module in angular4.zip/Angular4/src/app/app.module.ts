import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { RouterModule, Routes ,PreloadAllModules} from '@angular/router';
import {AdminComponent} from './Admin/admin.component';
import {EmployeeComponent} from './Employee/emp.component';
import {HomeComponent} from './Home/home.component';
import {HomeModule} from './Home/home.module';
import {EmployeeModule} from './Employee/emp.module';
import {AdminModule} from './Admin/admin.module';
import {LogInComponent} from './Login/login.component'

const routes: Routes = [  
  //{path:'',component:LogInComponent},
  { path: 'Home', loadChildren:()=> System.import('./Home').then((comp: any) => comp.default) },
  { path: 'Admin', loadChildren:()=> System.import('./Admin').then((comp: any) => comp.default) },
  { path: 'Employee', loadChildren:()=> System.import('./Employee').then((comp: any) => comp.default) },
];
@NgModule({
  declarations: [
    AppComponent, //LogInComponent    
  ],
  imports: [
    BrowserModule,
    HomeModule,
    EmployeeModule,
    AdminModule,    
    RouterModule.forRoot(routes, { useHash: false, preloadingStrategy: PreloadAllModules }),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
