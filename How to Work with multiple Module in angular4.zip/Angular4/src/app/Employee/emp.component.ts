import { Component } from '@angular/core';

@Component({
  selector: 'emp',
  templateUrl: './emp.component.html', 
})
export class EmployeeComponent {
  title = 'Employee component ';
}
