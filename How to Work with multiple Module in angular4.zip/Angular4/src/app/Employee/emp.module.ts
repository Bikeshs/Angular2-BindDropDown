import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {EmployeeComponent} from './emp.component';
const routes: Routes = [
  { path: 'Employee', component: EmployeeComponent },
];
@NgModule({
  declarations: [   
    EmployeeComponent   
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes) 
  ],
  providers: [],
  
})
export class EmployeeModule { }
