export class Emp {
    
}
