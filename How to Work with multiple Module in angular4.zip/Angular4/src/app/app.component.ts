import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html', 
})
export class AppComponent {
  title = 'Angular app using Angular CLI by Bikesh Srivastava ';
}
