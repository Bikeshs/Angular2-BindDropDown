import { Component } from '@angular/core';

@Component({
  selector: 'login',
  templateUrl: './login.component.html', 
})
export class LogInComponent {
  title = 'C# corner,Angular app using Angular CLI by Bikesh Srivastava ';
}
